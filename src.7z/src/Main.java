/**
 * Created by vrusa on 05.11.2017.
 */
public class Main {

    public static void main(String[] args){
        MainWindow mw = new MainWindow();
    }
}
